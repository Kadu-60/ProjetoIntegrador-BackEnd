package br.com.rd.ProjetoIntegrador.model.dto;

import lombok.Data;

@Data
public class EstoqueKeyDTO {
    private ProdutoDTO produto;
}

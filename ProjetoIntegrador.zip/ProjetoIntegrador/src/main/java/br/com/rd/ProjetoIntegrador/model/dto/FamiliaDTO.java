package br.com.rd.ProjetoIntegrador.model.dto;

import lombok.Data;

@Data
public class FamiliaDTO {
    private Long id_familia;
    private String descricao;
}
